/*
 * Decompiled with CFR.
 */
package me.pepperbell.continuity.module.setting;

import me.pepperbell.continuity.module.setting.Setting;

public final class BooleanSetting
extends Setting<BooleanSetting> {
    private boolean value;
    private final boolean originalValue;

    public BooleanSetting(CharSequence name, boolean value) {
        super(name);
        this.value = value;
        this.originalValue = value;
    }

    public void toggle() {
        this.setValue(!this.value);
    }

    public void setValue(boolean value) {
        this.value = value;
    }

    public boolean getOriginalValue() {
        return this.originalValue;
    }

    public boolean getValue() {
        return this.value;
    }
}

